PATTERNS = {
    'Coltrane pattern (minor)': ['1', 'b3', '4', '5'],
    'Coltrane pattern (major)': ['1', '2' , '3', '5']
            }
