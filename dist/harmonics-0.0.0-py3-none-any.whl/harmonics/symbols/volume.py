class Volume:
    def __init__(self, velocity):
        self.velocity = velocity

    def __repr__(self): return str(self.velocity)
