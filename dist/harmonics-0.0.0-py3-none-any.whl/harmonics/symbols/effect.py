class Effect:
    def __init__(self, mod):
        self.mod = mod

    def __repr__(self): return str(self.mod)
