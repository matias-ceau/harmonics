import numpy as np
import pandas as pd
from dataclasses import dataclass

import harmonics._utils


class Context():

    "Harmonic, rhytmic context for a note, used in Part and Song."

    def __init__(self, key='C', mode=1, time_signature='4:4', chord=None):
        self.key = key
        self.mode = mode
        self.time_signature = time_signature
        self.chord = chord

    def __eq__(self, context):
        if isinstance(context, Context):
            return (self.key == context.key)\
                 & (self.mode == context.mode)\
                 & (self.time_signature == context.time_signature)\
                 & (self.chord == context.chord)


class Instrument():
    """Mainly a property of a part."""

    def __init__(self,
                 name=None,
                 channel=None,
                 bank=None,
                 instrument_type=None):
        self.name = name
        self.channel = channel
        self.bank = bank
        self.instrument_type = instrument_type


class Interval():

    """Encapsulates the concept of an interval."""

    def __init__(self, name):
        if isinstance(name, Interval):
            self.__dict__.update(vars(name))
            return
        else:
            if name in Harmonics.INAMES:
                self.name = name
                self.distance = Harmonics.IDICT[name]
                if int(self.name.split('b')[-1].split('#')[-1]) > 7:
                    self.distance += 12
            else:
                if type(name) in [tuple, list]:
                    if len(name) == 2 and type(name[0]) == Note:
                        self.distance = name[1].midi - name[0].midi
                else:
                    self.distance = name
                candidates = [a for a, b in Harmonics.IDICT.items()
                              if b == self.distance % 12]
                if self.distance > 12:
                    candidates = [
                        c for c in candidates
                        if self.Harmonics.EDICT[c] in (1, 2)]
                elif self.distance < 12:
                    candidates = [
                        c for c in candidates
                        if self.Harmonics.EDICT[c] in (0, 2)]
                self.name = candidates[0]
            self.other_names = [
                a for a, b in Harmonics.IDICT.items()
                if b == self.distance % 12]
            for a in Harmonics.INTERVALS.keys():
                self._detect(a)
            self.octave = (self.distance//12)

    def _detect(self, class_attribute):
        if type(Harmonics.INTERVALS[class_attribute][0]) == str:
            attribute = self.name
        else:
            attribute = self.distance
        if attribute in Harmonics.INTERVALS[class_attribute]:
            self.__dict__[class_attribute.lower()] = True
        else:
            self.__dict__[class_attribute.lower()] = False

    def __repr__(self): return self.name
    def __str__(self): return self.name

    def __eq__(self, interval):
        if isinstance(interval, Interval):
            return self.distance == interval.distance
        elif type(interval) == str:
            return self.distance == Interval(str)
        else:
            return self.distance == interval

    def __add__(self, interval):
        if type(interval) == Interval:
            return Interval(self.distance + interval.distance)
        elif type(interval) == int:
            return Interval(self.distance + interval)

    def __sub__(self, interval):
        if type(interval) == Interval:
            return Interval((self.distance - interval.distance) % 12)
        elif type(interval) == int:
            return Interval((self.distance - interval) % 12)

    def __invert__(self):
        if self.distance < 0:
            return Interval(abs(self.distance-12) % 12)
        if self.distance > 0:
            return Interval(abs(self.distance+12) % 12)
        if self.distance == 0:
            return Interval(0)


class Pattern():

    """A sequence of intervals."""

    @classmethod
    def find_pattern(cls, arr, seq):
        Na, Nseq = arr.size, seq.size
        r_seq = np.arange(Nseq)
        M = (arr[np.arange(Na-Nseq+1)[:, None] + r_seq] == seq).all(1)
        if M.any() > 0:
            return np.where(np.convolve(M, np.ones((Nseq), dtype=int)) > 0)[0]
        else:
            return []

    def __init__(self, name='', notes=None, intervals=None):
        self.name = name
        self.notes = notes
        self.intervals = intervals
        if notes:
            try:
                self.intervals = [a//b for a, b in zip(notes, notes[1:])]
                self.distance = np.array([i.distance for i in self.intervals])
            except TypeError:
                pass
        elif name:
            try:
                intervals_from_start = {
                    Interval(i) for i in Harmonics.FORMULAS[self.name]}
                self.distance = np.array(
                    [(b-a).distance for a, b in zip(intervals_from_start,
                                                    intervals_from_start[1:])])
                self.intervals = [Interval(i) for i in self.distance]
            except KeyError:
                pass
        else:
            return

    def __repr__(self): return '--' + \
        '--'.join([str(i) for i in self.distance])+'--'

    def __str__(self): return '--' + \
        '--'.join([str(i) for i in self.intervals])+'--'


class Pitch:

    @classmethod
    def freq2pitch(cls, freq): return round(np.log2(freq/440)*12+69)
    @classmethod
    def pitch2freq(cls, pitch): return 440*np.power(2, (pitch-69)/12)

    def __init__(self, n):
        if type(n) in [int, float]:
            self.midi = n
        elif type(n) == str:
            if n[-1] == 'z':
                self.frequency = float(n[:-2])
                self.midi = Pitch.freq2pitch(self.frequency)
            else:
                if n[-1].isnumeric():
                    self.octave = int(n[-1])
                    self.name = n[:-1]
                else:
                    self.name = n
                    self.octave = Note.DEF_OCTAVE
                self.midi = Note.NDICT[self.name] + (self.octave+1)*12
        else:
            print('wut?')
        if 'name' not in self.__dict__:
            self.name = Pitch.midi_to_note(self.midi)
        if 'octave' not in self.__dict__:
            self.octave = Pitch.midi_octave(self.midi)
        # computed
        self.equivalents = [
            a for a, b in Note.NDICT.items() if self.midi % 12 == b]
        self.pitch_class = Note.NDICT[self.name]
        if 'frequency' not in self.__dict__:
            self.frequency = Pitch.pitch2freq(self.midi)
        self.offpitch\
            = f'{1200*np.log2(self.frequency/Pitch.pitch2freq(self.midi))}\
                cents'

    def __repr__(self): return self.name


class Duration:
    def __init__(self, duration):
        self.duration = duration

    def __repr__(self): return str(self.duration)+' beat(s)'


class Volume:
    def __init__(self, velocity):
        self.velocity = velocity

    def __repr__(self): return str(self.velocity)


class Mod:
    def __init__(self, mod):
        self.mod = mod

    def __repr__(self): return str(self.mod)


@dataclass
class NoteData:
    message_type: str
    instrument:      int
    pitch:        int
    volume:        int
    duration:     float


class Note:
    is_note = True
    DEF_OCTAVE = Harmonics.DEF_OCTAVE
    NDICT = Harmonics.NDICT

    @classmethod
    def fromData(cls, obj):
        if obj.message_type == 'note_on':
            # need to convert duration and maybe change channel to instrument
            return cls(obj.pitch,
                       volume=obj.volume,
                       duration=obj.duration,
                       instrument=obj.instrument)

    def __init__(self, n,
                 duration=1,  # unit?
                 volume=100,  # units
                 mod=None,
                 kind=None,
                 instrument=0):
        self.pitch = Pitch(n)
        self.duration = Duration(duration)
        self.volume = Volume(volume)
        self.mod = Mod(mod)
        self.type = kind
        self.instrument = Instrument(instrument)

    def __eq__(self, note):
        return self.pitch == note

    def __floordiv__(self, note):
        if isinstance(note, Note):
            return Interval([self.pitch, note.pitch])

    def __truediv__(self, note):
        if isinstance(note, Note):
            distance = Interval([self.pitch, note.pitch]).distance
            octaves = distance // 12
            semis = distance % 12
            return f"{octaves} octaves and {semis} semitones"

    def __str__(self): return repr(self.pitch)
    def __repr__(self): return repr(self.pitch)
    def __len__(self): return self.pitch.midi

    def __add__(self, note):
        if type(note) == Interval:
            return Note(n=self.pitch.midi+note.distance,
                        duration=self.duration,
                        volume=self.volume,
                        mod=self.mod)
        if type(note) == Note:
            return Sequence(notes=[self, note])

    def enharmonic(self, spelling='b', name=''):
        if (name != '') and name in self.pitch.equivalents:
            self.name = name
        if spelling == 'natural':
            selection = [i for i in self.pitch.equivalents if (
                'b' not in i) & ('#' not in i)]
        else:
            selection = [i for i in self.pitch.equivalents if spelling in i]
        if len(selection):
            self.name = selection[0]

    def append(self, note):
        if type(note) == Note:
            return Sequence(notes=[self, note])

    def to_data(self):
        # if mod also return CC message
        return NoteData('note_on',
                        self.instrument.name,
                        self.pitch.midi,
                        self.volume.velocity,
                        self.duration.duration)


class Chord(Note):
    DEFAULT_ROOT = Harmonics.DEFAULT_KEY
    CHORDS = {k: [Interval(i) for i in v[0]]
              for k, v in Harmonics.CHORDS.items()}

    def __init__(self, chord='', notes=None, root='', key=''):
        self.key = key
        self.root = root
        if chord:
            self.chord = chord
            self.formula = self.CHORDS[chord]
            if not self.root:
                self.root = Chord.DEFAULT_ROOT
            self.notes = [Note(i) for i in [Note(
                self.root).midi + i.distance for i in self.formula]]
        elif notes:
            pass
        self.respell()
        if not self.root:
            pass

    def respell(self):
        if not self.key:
            def _respell(acc):
                for n in self.notes:
                    n.enharmonic(spelling=acc)
            if ('b' in self.root) or ('b' in ' '.join(
                    [i.name for i in self.formula])
                                      ):
                _respell('b')
            if ('#' in self.root) or ('#' in ' '.join(
                    [i.name for i in self.formula])
                                      ):
                _respell('#')
            _respell('natural')
        if self.key:
            pass  # right spelling depending on the key


class Sequence():
    """Melody, bassline or drum part."""

    DEFAULT_REF = Harmonics.DEFAULT_KEY

    def __init__(self, notes=None, key=None):
        super().__init__()
        self.notes = notes
        self.key = key
        if not self.key:
            self.key = self.DEFAULT_REF
        self.part_type = None
        self.respell()

    def __getitem__(self, index):
        if type(index) == int:
            return self.notes[index]
        return Sequence(notes=self.notes[index],
                        key=self.key,
                        part_type=self.part_type)

    def __add__(self, obj):
        if isinstance(obj, Sequence):
            return Sequence(notes=self.notes+obj.notes,
                            part_type=self.part_type,
                            key=self.key)
        if isinstance(obj, Note):
            print(self.notes)
            print(obj)
            return Sequence(notes=self.notes+[obj],
                            part_type=self.part_type,
                            key=self.key)

    def __contains__(self, note):
        return [note == n for n in self.notes]

    def __repr__(self):
        return str(self.notes)

    @property
    def df(self):
        df = pd.DataFrame([i.to_data() for i in self.notes])
        df['beat_time'] = 0  # ""
        df['_miditime'] = [0]+df._duration.to_list()[:-1]

    def respell(self, names=[]):
        if names:
            for name in names:
                for note in self.notes:
                    note.enharmonic(name=name)
        else:
            def _respell(acc):
                for n in self.notes:
                    n.enharmonic(spelling=acc)
            if 'b' in str(self.key):
                _respell('b')
            if '#' in str(self.key):
                _respell('#')
            _respell('natural')


class Tune:
    """A collection of sequences"""
    pass
