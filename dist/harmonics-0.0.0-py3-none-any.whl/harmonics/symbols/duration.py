class Duration:
    def __init__(self, duration):
        self.duration = duration

    def __repr__(self): return str(self.duration)+' beat(s)'
